package com.example.miniproject.Interface;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.miniproject.Entity.Employee;
import com.example.miniproject.Entity.Project;


@Repository
public interface ProjectRepository extends JpaRepository<Project,Long>{
    Project findByProjname(String projectName);

    List<Project> findByProjnameContaining(String keyword);

    List<Employee> findEmployeesByProjId(Long projId);



}
