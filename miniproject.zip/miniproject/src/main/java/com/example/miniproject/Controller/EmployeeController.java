package com.example.miniproject.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.miniproject.Entity.Employee;
import com.example.miniproject.Service.EmployeeService;


@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

   @Autowired
    private final EmployeeService employeeService;

   
    public EmployeeController(EmployeeService employeeService){
        this.employeeService = employeeService;
    }

    @GetMapping
    public List<Employee> getAllEmployees(){
        return employeeService.getAllEmployee();
    }


    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id")Long id) {
      Employee employee = employeeService.getEmployeeById(id);
      if (employee != null) {
        return ResponseEntity.ok(employee);
      } else {
        return ResponseEntity.notFound().build();
      }
    }
    @PostMapping
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        Employee savedEmployee = employeeService.saveEmployee(employee);
        return ResponseEntity.ok(savedEmployee);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable("id") Long id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }


   
}

