package com.example.miniproject.Interface;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.miniproject.Entity.Department;
import com.example.miniproject.Entity.Employee;



@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByName(String name);

    List<Employee> findByDepartment(Department department);

    List<Employee> findByPosition(String position);

    List<Employee> findByNameAndDepartment(String name, Department department);

    List<Employee> findByNameOrPosition(String name, String position);

    List<Employee> findByDepartmentAndPosition(Department department, String position);

    List<Employee> findByNameContaining(String keyword);
}

