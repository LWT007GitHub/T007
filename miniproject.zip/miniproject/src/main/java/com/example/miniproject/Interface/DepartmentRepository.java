package com.example.miniproject.Interface;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.miniproject.Entity.Department;
import com.example.miniproject.Entity.Employee;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long>{
    
    Department findByDepartname(String department_name);

    List<Department> findByDepartnameContaining(String name);

    List<Employee> findEmployeesByDepartmentId(Long departmentId);

    
}

