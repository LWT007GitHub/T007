package com.example.miniproject.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.miniproject.Entity.Department;
import com.example.miniproject.Service.DepartmentService;

@RestController
@RequestMapping("/api/department")
public class DepartmentController {

    @Autowired
    private final DepartmentService departmentService;
    
    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentService.getAllDepartments();
    }

    @GetMapping("/{departmentId}")
        ResponseEntity<Department> getDepartmentById(@PathVariable Long departmentId) {
        Optional<Department> departmentOptional = departmentService.getDepartmentById(departmentId);
        Department department = departmentOptional.orElse(null);
        if (department != null) {
            return ResponseEntity.ok(department);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
public ResponseEntity<Department> createDepartment(@RequestBody Department department) {
    Department savedDepartment = departmentService.saveDepartment(department);
    return ResponseEntity.ok(savedDepartment);
}

    @DeleteMapping("/{departmentId}")
    public ResponseEntity<String> deleteDepartment(@PathVariable Long departmentId) {
        departmentService.deleteDepartment(departmentId);
        return ResponseEntity.ok("Department deleted successfully");
    }

}