package com.example.miniproject.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.miniproject.Entity.Employee;
import com.example.miniproject.Interface.EmployeeRepository;


@Service
public class EmployeeService {
    @Autowired
    private final EmployeeRepository employeeRepository;

    
    

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;

    }

    public List<Employee> getAllEmployee(){
        return employeeRepository.findAll();
    }


    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

}

